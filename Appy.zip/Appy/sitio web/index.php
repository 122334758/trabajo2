<?php
// --- CONFIGURACIÓN BASE DE DATOS ---
$host = 'localhost';
$db   = 'videos_db';
$user = 'root'; // tu usuario
$pass = '';     // tu contraseña
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

// --- CREAR TABLA SI NO EXISTE ---
$pdo->exec("CREATE TABLE IF NOT EXISTS videos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    descripcion TEXT,
    archivo VARCHAR(255) NOT NULL,
    fecha_subida TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// --- SUBIR VIDEO ---
$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['archivo'])) {
    $titulo = $_POST['titulo'];
    $descripcion = $_POST['descripcion'];
    $archivo = $_FILES['archivo']['name'];
    $tmp_name = $_FILES['archivo']['tmp_name'];
    
    if (!is_dir('uploads')) mkdir('uploads'); // crear carpeta si no existe
    $ruta = 'uploads/' . $archivo;

    if (move_uploaded_file($tmp_name, $ruta)) {
        $stmt = $pdo->prepare("INSERT INTO videos (titulo, descripcion, archivo) VALUES (?, ?, ?)");
        $stmt->execute([$titulo, $descripcion, $archivo]);
        header("Location: ".$_SERVER['PHP_SELF']);
        exit;
    } else {
        $error = "Error al subir el video.";
    }
}

// --- OBTENER VIDEOS ---
$stmt = $pdo->query("SELECT * FROM videos ORDER BY fecha_subida DESC");
$videos = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Galería de Videos</title>
<style>
/* --- RESET BÁSICO --- */
* { margin:0; padding:0; box-sizing:border-box; font-family: 'Arial', sans-serif; }
body { background:#121212; color:#fff; }

/* --- CABECERA --- */
header { background:#1f1f1f; padding:20px; text-align:center; box-shadow:0 2px 10px rgba(0,0,0,0.5); }
header h1 { font-size:2em; margin-bottom:10px; }

/* --- FORMULARIO SUBIR VIDEO --- */
.form-container { max-width:500px; margin:20px auto; padding:20px; background:#1e1e1e; border-radius:10px; box-shadow:0 0 10px #000; }
form label { display:block; margin:10px 0 5px; }
form input, form textarea { width:100%; padding:8px; border:none; border-radius:5px; background:#2c2c2c; color:#fff; }
form button { margin-top:15px; padding:10px 20px; background:#ff5722; border:none; border-radius:5px; cursor:pointer; transition:0.3s; }
form button:hover { background:#e64a19; }
.error { color:red; text-align:center; margin-bottom:10px; }

/* --- REJILLA DE VIDEOS --- */
.videos-container { display:grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap:20px; padding:20px; }
.video-card { background:#1f1f1f; border-radius:10px; overflow:hidden; transition: transform 0.3s; box-shadow:0 0 10px #000; }
.video-card:hover { transform: scale(1.05); }
.video-card video { width:100%; display:block; }
.video-card h3 { padding:10px; font-size:1.2em; }
.video-card p { padding:0 10px 10px; font-size:0.9em; color:#ccc; }
.video-card small { display:block; padding:0 10px 10px; color:#888; font-size:0.8em; }
</style>
</head>
<body>

<header>
<h1>Galería de Videos</h1>
</header>

<div class="form-container">
<?php if($error) echo "<p class='error'>$error</p>"; ?>
<form method="POST" enctype="multipart/form-data">
    <label>Título:</label>
    <input type="text" name="titulo" required>
    <label>Descripción:</label>
    <textarea name="descripcion"></textarea>
    <label>Archivo de Video:</label>
    <input type="file" name="archivo" accept="video/mp4" required>
    <button type="submit">Subir Video</button>
</form>
</div>

<div class="videos-container">
<?php foreach($videos as $video): ?>
    <div class="video-card">
        <video controls>
            <source src="uploads/<?= htmlspecialchars($video['archivo']) ?>" type="video/mp4">
            Tu navegador no soporta video.
        </video>
        <h3><?= htmlspecialchars($video['titulo']) ?></h3>
        <p><?= htmlspecialchars($video['descripcion']) ?></p>
        <small>Subido: <?= $video['fecha_subida'] ?></small>
    </div>
<?php endforeach; ?>
</div>

</body>
</html>
