#!/usr/bin/env python3
"""
Tetris simple pero completo usando pygame.
Guarda como tetris.py y ejecuta: python tetris.py
Controles:
- ← / → : mover
- ↓ : soft drop
- space : hard drop
- z / up : rotar (sentido antihorario con Z, horario con up)
- c : hold
- p : pausar
- r : reiniciar (en Game Over)
"""

import pygame
import random
import sys

# ---------- Config ----------
CELL = 30
COLUMNS = 10
ROWS = 20
WIDTH = CELL * (COLUMNS + 6)  # espacio para next/hold
HEIGHT = CELL * ROWS
FPS = 60

BLACK = (10, 10, 10)
GRAY = (40, 40, 40)
WHITE = (230, 230, 230)

# Tetrominos (rotations)
# Each tetromino is a list of rotation states; each state is list of (x,y) blocks
TETROMINOS = {
    'I': [
        [(0,1),(1,1),(2,1),(3,1)],
        [(2,0),(2,1),(2,2),(2,3)],
    ],
    'J': [
        [(0,0),(0,1),(1,1),(2,1)],
        [(1,0),(2,0),(1,1),(1,2)],
        [(0,1),(1,1),(2,1),(2,2)],
        [(1,0),(1,1),(1,2),(0,2)],
    ],
    'L': [
        [(2,0),(0,1),(1,1),(2,1)],
        [(1,0),(1,1),(1,2),(2,2)],
        [(0,1),(1,1),(2,1),(0,2)],
        [(0,0),(1,0),(1,1),(1,2)],
    ],
    'O': [
        [(1,0),(2,0),(1,1),(2,1)],
    ],
    'S': [
        [(1,0),(2,0),(0,1),(1,1)],
        [(1,0),(1,1),(2,1),(2,2)],
    ],
    'T': [
        [(1,0),(0,1),(1,1),(2,1)],
        [(1,0),(1,1),(2,1),(1,2)],
        [(0,1),(1,1),(2,1),(1,2)],
        [(1,0),(0,1),(1,1),(1,2)],
    ],
    'Z': [
        [(0,0),(1,0),(1,1),(2,1)],
        [(2,0),(1,1),(2,1),(1,2)],
    ],
}

COLORS = {
    'I': (0, 240, 240),
    'J': (0, 0, 240),
    'L': (240, 160, 0),
    'O': (240, 240, 0),
    'S': (0, 240, 0),
    'T': (160, 0, 240),
    'Z': (240, 0, 0),
}

# Scoring rules
SCORE_TABLE = {0:0, 1:40, 2:100, 3:300, 4:1200}  # base points multiplied by level

# ---------- Helper functions ----------
def create_grid():
    return [[None for _ in range(COLUMNS)] for _ in range(ROWS)]

def rotate_piece(piece):
    # advance rotation index modulo states
    return (piece['rotation'] + 1) % len(TETROMINOS[piece['shape']])

def get_blocks(piece, rotation=None, pos=None):
    """Return list of absolute (x,y) coordinates on the board for the piece."""
    if rotation is None:
        rotation = piece['rotation']
    if pos is None:
        pos = (piece['x'], piece['y'])
    shape = piece['shape']
    state = TETROMINOS[shape][rotation]
    blocks = [(pos[0] + bx, pos[1] + by) for bx, by in state]
    return blocks

def valid_position(grid, piece, rotation=None, pos=None):
    for x, y in get_blocks(piece, rotation, pos):
        if x < 0 or x >= COLUMNS or y < 0 or y >= ROWS:
            return False
        if grid[y][x] is not None:
            return False
    return True

def lock_piece(grid, piece):
    for x, y in get_blocks(piece):
        if 0 <= y < ROWS and 0 <= x < COLUMNS:
            grid[y][x] = piece['shape']

def clear_lines(grid):
    cleared = 0
    new_grid = [row for row in grid if any(cell is None for cell in row)]
    cleared = ROWS - len(new_grid)
    for _ in range(cleared):
        new_grid.insert(0, [None for _ in range(COLUMNS)])
    return new_grid, cleared

def new_piece(rand_seed=None):
    shape = random.choice(list(TETROMINOS.keys()))
    piece = {
        'shape': shape,
        'rotation': 0,
        'x': COLUMNS // 2 - 2,
        'y': 0,
    }
    # shift up for taller rotations (rough)
    return piece

# ---------- Game class ----------
class Tetris:
    def __init__(self):
        self.grid = create_grid()
        self.score = 0
        self.level = 0
        self.lines = 0
        self.game_over = False
        self.paused = False

        self.bag = []
        self.next_queue = []
        self.refill_bag()

        self.current = self.spawn_piece()
        self.hold_piece = None
        self.hold_used = False

        # timing
        self.gravity = 0.8  # cells per second base, will scale with level
        self.drop_accumulator = 0.0
        self.lock_delay = 0.5
        self.lock_timer = 0.0
        self.soft_drop = False

    def refill_bag(self):
        pieces = list(TETROMINOS.keys())
        random.shuffle(pieces)
        self.bag.extend(pieces)
        # ensure next_queue length
        while len(self.next_queue) < 5:
            if not self.bag:
                random.shuffle(pieces)
                self.bag.extend(pieces)
            self.next_queue.append(self.bag.pop(0))

    def spawn_piece(self):
        if not self.next_queue:
            self.refill_bag()
        shape = self.next_queue.pop(0)
        self.refill_bag()
        piece = {'shape': shape, 'rotation':0, 'x': COLUMNS//2 -2, 'y': 0}
        # if initial position collides -> game over
        if not valid_position(self.grid, piece):
            self.game_over = True
        self.hold_used = False
        return piece

    def hard_drop(self):
        while valid_position(self.grid, self.current, pos=(self.current['x'], self.current['y']+1)):
            self.current['y'] += 1
        # lock immediately
        self.lock_piece_and_continue()

    def soft_drop_step(self):
        if valid_position(self.grid, self.current, pos=(self.current['x'], self.current['y']+1)):
            self.current['y'] += 1
            return True
        else:
            # start lock timer
            return False

    def rotate_current(self, clockwise=True):
        old_rot = self.current['rotation']
        if clockwise:
            new_rot = (old_rot + 1) % len(TETROMINOS[self.current['shape']])
        else:
            new_rot = (old_rot - 1) % len(TETROMINOS[self.current['shape']])
        # simple wall kicks: try no kick, left, right, up
        kicks = [(0,0), (-1,0), (1,0), (-2,0), (2,0), (0,-1)]
        for dx, dy in kicks:
            if valid_position(self.grid, self.current, rotation=new_rot, pos=(self.current['x']+dx, self.current['y']+dy)):
                self.current['rotation'] = new_rot
                self.current['x'] += dx
                self.current['y'] += dy
                return True
        return False

    def move(self, dx):
        if valid_position(self.grid, self.current, pos=(self.current['x']+dx, self.current['y'])):
            self.current['x'] += dx
            return True
        return False

    def update(self, dt):
        if self.game_over or self.paused: 
            return

        # gravity scales with level
        speed = self.gravity + self.level * 0.15
        if self.soft_drop:
            speed *= 20  # accelerate soft drop

        self.drop_accumulator += dt * speed

        moved = False
        while self.drop_accumulator >= 1.0:
            self.drop_accumulator -= 1.0
            if valid_position(self.grid, self.current, pos=(self.current['x'], self.current['y']+1)):
                self.current['y'] += 1
                self.lock_timer = 0.0
                moved = True
            else:
                # cannot move down -> start lock timer
                self.lock_timer += 1.0 / FPS
                if self.lock_timer >= self.lock_delay:
                    self.lock_piece_and_continue()
                    break

    def lock_piece_and_continue(self):
        lock_piece(self.grid, self.current)
        self.grid, cleared = clear_lines(self.grid)
        if cleared:
            self.lines += cleared
            self.score += SCORE_TABLE.get(cleared, 0) * (self.level + 1)
            # level up every 10 lines
            self.level = self.lines // 10
        # spawn next
        self.current = self.spawn_piece()
        self.drop_accumulator = 0.0
        self.lock_timer = 0.0

    def hold(self):
        if self.hold_used:
            return
        if self.hold_piece is None:
            self.hold_piece = self.current['shape']
            self.current = self.spawn_piece()
        else:
            # swap
            shape = self.hold_piece
            self.hold_piece = self.current['shape']
            self.current = {'shape': shape, 'rotation':0, 'x': COLUMNS//2 -2, 'y': 0}
            if not valid_position(self.grid, self.current):
                self.game_over = True
        self.hold_used = True

    def reset(self):
        self.__init__()

# ---------- Pygame UI ----------
def draw_grid(surface, grid, offset_x, offset_y):
    for y in range(ROWS):
        for x in range(COLUMNS):
            rect = pygame.Rect(offset_x + x*CELL, offset_y + y*CELL, CELL, CELL)
            pygame.draw.rect(surface, GRAY, rect, 1)
            if grid[y][x]:
                color = COLORS.get(grid[y][x], WHITE)
                pygame.draw.rect(surface, color, rect.inflate(-2, -2))

def draw_piece(surface, piece, offset_x, offset_y, alpha=False):
    color = COLORS.get(piece['shape'], WHITE)
    for x, y in get_blocks(piece):
        rect = pygame.Rect(offset_x + x*CELL, offset_y + y*CELL, CELL, CELL)
        pygame.draw.rect(surface, color, rect.inflate(-2, -2))
        if alpha:
            s = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
            s.fill((255,255,255,100))
            surface.blit(s, rect.topleft)

def draw_next(surface, queue, offset_x, offset_y):
    small = CELL // 2
    font = pygame.font.SysFont(None, 20)
    surface.blit(font.render("Siguiente:", True, WHITE), (offset_x, offset_y))
    y = offset_y + 24
    for i, shape in enumerate(queue[:5]):
        states = TETROMINOS[shape][0]
        # center
        for bx, by in states:
            rx = offset_x + 40 + bx*small
            ry = y + i*60 + by*small
            rect = pygame.Rect(rx, ry, small, small)
            pygame.draw.rect(surface, COLORS[shape], rect.inflate(-1, -1))

def draw_hold(surface, hold, offset_x, offset_y):
    font = pygame.font.SysFont(None, 20)
    surface.blit(font.render("Hold:", True, WHITE), (offset_x, offset_y))
    if hold:
        states = TETROMINOS[hold][0]
        small = CELL // 2
        for bx, by in states:
            rx = offset_x + 40 + bx*small
            ry = offset_y + 30 + by*small
            rect = pygame.Rect(rx, ry, small, small)
            pygame.draw.rect(surface, COLORS[hold], rect.inflate(-1, -1))

def draw_ui(surface, game, offset_x, offset_y):
    font = pygame.font.SysFont(None, 24)
    surface.blit(font.render(f"Score: {game.score}", True, WHITE), (offset_x, offset_y))
    surface.blit(font.render(f"Level: {game.level}", True, WHITE), (offset_x, offset_y + 30))
    surface.blit(font.render(f"Lines: {game.lines}", True, WHITE), (offset_x, offset_y + 60))

def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Tetris - Bruno")
    clock = pygame.time.Clock()
    font_big = pygame.font.SysFont(None, 48)
    font = pygame.font.SysFont(None, 28)

    game = Tetris()

    board_offset_x = CELL * 1
    board_offset_y = 0

    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0  # seconds
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    game.paused = not game.paused
                if game.game_over:
                    if event.key == pygame.K_r:
                        game.reset()
                    continue
                if event.key == pygame.K_LEFT:
                    game.move(-1)
                elif event.key == pygame.K_RIGHT:
                    game.move(1)
                elif event.key == pygame.K_DOWN:
                    game.soft_drop = True
                elif event.key == pygame.K_SPACE:
                    game.hard_drop()
                elif event.key == pygame.K_z:
                    game.rotate_current(clockwise=False)
                elif event.key == pygame.K_UP:
                    game.rotate_current(clockwise=True)
                elif event.key == pygame.K_c:
                    game.hold()
            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_DOWN:
                    game.soft_drop = False

        game.update(dt)

        # draw
        screen.fill(BLACK)
        # board bg
        board_rect = pygame.Rect(board_offset_x - 4, board_offset_y - 4, COLUMNS*CELL + 8, ROWS*CELL + 8)
        pygame.draw.rect(screen, GRAY, board_rect, 2)
        draw_grid(screen, game.grid, board_offset_x, board_offset_y)
        if not game.game_over:
            draw_piece(screen, game.current, board_offset_x, board_offset_y)

        # ghost piece
        ghost = dict(game.current)
        while valid_position(game.grid, ghost, pos=(ghost['x'], ghost['y']+1)):
            ghost['y'] += 1
        # draw ghost with alpha
        for x, y in get_blocks(ghost):
            rect = pygame.Rect(board_offset_x + x*CELL, board_offset_y + y*CELL, CELL, CELL)
            s = pygame.Surface((rect.width-2, rect.height-2), pygame.SRCALPHA)
            s.fill((200,200,200,100))
            screen.blit(s, (rect.x+1, rect.y+1))

        # next and hold
        draw_next(screen, game.next_queue, board_offset_x + COLUMNS*CELL + 20, 20)
        draw_hold(screen, game.hold_piece, board_offset_x + COLUMNS*CELL + 20, 220)
        draw_ui(screen, game, board_offset_x + COLUMNS*CELL + 20, 360)

        if game.paused:
            s = font_big.render("PAUSA", True, WHITE)
            screen.blit(s, (WIDTH//2 - s.get_width()//2, HEIGHT//2 - s.get_height()//2))
        if game.game_over:
            go = font_big.render("GAME OVER", True, WHITE)
            tip = font.render("Presiona R para reiniciar", True, WHITE)
            screen.blit(go, (WIDTH//2 - go.get_width()//2, HEIGHT//2 - go.get_height()//2 - 20))
            screen.blit(tip, (WIDTH//2 - tip.get_width()//2, HEIGHT//2 + 30))

        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
