import requests
import urllib.parse

def search_web(query: str, max_chars: int = 800) -> str:
	"""
	Busca un resumen rápido en DuckDuckGo Instant Answer API.
	Devuelve texto (puede estar vacío si no hay resumen).
	"""
	if not query:
		return ""
	try:
		url = "https://api.duckduckgo.com/"
		params = {
			"q": query,
			"format": "json",
			"no_html": 1,
			"skip_disambig": 1
		}
		resp = requests.get(url, params=params, timeout=5)
		if resp.status_code == 200:
			data = resp.json()
			# Priorizar AbstractText
			abstract = data.get("AbstractText") or ""
			if abstract:
				return abstract[:max_chars]
			# Buscar en RelatedTopics
			related = data.get("RelatedTopics", [])
			for item in related:
				if isinstance(item, dict):
					text = item.get("Text", "")
					if text:
						return text[:max_chars]
		return ""
	except Exception:
		return ""
