import os
import sqlite3
from datetime import datetime
import difflib

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "memory.db")
DB_PATH = os.path.abspath(DB_PATH)

def init_db():
	"""Crea la tabla si no existe."""
	conn = sqlite3.connect(DB_PATH)
	c = conn.cursor()
	c.execute("""
	CREATE TABLE IF NOT EXISTS memories (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		query TEXT NOT NULL,
		response TEXT NOT NULL,
		timestamp TEXT NOT NULL
	)
	""")
	conn.commit()
	conn.close()

def save_memory(query: str, response: str):
	"""Guarda un par query-response en la BD."""
	if not query or not response:
		return
	conn = sqlite3.connect(DB_PATH)
	c = conn.cursor()
	c.execute("INSERT INTO memories (query, response, timestamp) VALUES (?, ?, ?)",
			  (query, response, datetime.utcnow().isoformat()))
	conn.commit()
	conn.close()

def recall_memory(query: str, cutoff: float = 0.6):
	"""
	Intentar recuperar una respuesta previa similar a 'query'.
	Usa difflib.get_close_matches sobre las queries guardadas.
	"""
	if not query:
		return None
	conn = sqlite3.connect(DB_PATH)
	c = conn.cursor()
	c.execute("SELECT id, query, response FROM memories")
	rows = c.fetchall()
	conn.close()
	if not rows:
		return None
	queries = [r[1] for r in rows]
	matches = difflib.get_close_matches(query, queries, n=1, cutoff=cutoff)
	if not matches:
		return None
	best = matches[0]
	# encontrar response correspondiente
	for r in rows:
		if r[1] == best:
			return r[2]
	return None
