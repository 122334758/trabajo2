import speech_recognition as sr
import pyttsx3
from config import OPENAI_API_KEY, VOICE_RATE, VOICE_VOLUME
from modules.web_search import search_web
from modules.tasks import init_db, save_memory, recall_memory

# Intentar importar openai y manejar la ausencia del paquete
try:
    import openai
    from openai import error as openai_error
    OPENAI_AVAILABLE = True
except Exception:
    openai = None
    openai_error = None
    OPENAI_AVAILABLE = False

# Inicializar OpenAI si la librería y la clave están disponibles
if OPENAI_AVAILABLE and OPENAI_API_KEY:
    openai.api_key = OPENAI_API_KEY
else:
    # Si falta la librería o la clave, ask_openai devolverá mensajes informativos.
    pass

# Inicializar voz (con manejo de fallo)
try:
    engine = pyttsx3.init()
    engine.setProperty('rate', VOICE_RATE)
    engine.setProperty('volume', VOICE_VOLUME)
except Exception:
    engine = None
    # fallo al inicializar pyttsx3; la salida de voz se omitirá silenciosamente.
    pass

def speak(text):
    print(f"Harvis: {text}")
    if engine:
        try:
            engine.say(text)
            engine.runAndWait()
        except Exception:
            # en entornos sin salida de audio, solo imprimir
            pass

def listen():
    r = sr.Recognizer()
    try:
        with sr.Microphone() as source:
            # Ajuste rápido para reducir ruido de fondo
            try:
                r.adjust_for_ambient_noise(source, duration=0.8)
            except Exception:
                pass
            print("Escuchando...")
            try:
                audio = r.listen(source, timeout=5, phrase_time_limit=8)
            except sr.WaitTimeoutError:
                return None
        try:
            query = r.recognize_google(audio, language="es-ES")
            print(f"Tú: {query}")
            return query
        except Exception:
            speak("No entendí, repite por favor.")
            return None
    except Exception:
        # Fallback a entrada por texto si no hay micrófono (útil para desarrollo)
        try:
            query = input("Entrada (texto): ").strip()
            if query == "":
                return None
            print(f"Tú: {query}")
            return query
        except Exception:
            return None

def ask_openai(prompt: str) -> str:
    if not OPENAI_AVAILABLE:
        return "Paquete 'openai' no instalado. Instálalo con: pip install openai"
    if not OPENAI_API_KEY:
        return "No se ha configurado la clave de OpenAI. Coloca OPENAI_API_KEY en las variables de entorno."
    try:
        # Usar Chat Completions (gpt-3.5-turbo) para respuestas más naturales
        messages = [
            {"role": "system", "content": "Eres un asistente útil que responde en español de forma clara y concisa."},
            {"role": "user", "content": prompt},
        ]
        resp = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=messages,
            max_tokens=400,
            temperature=0.6,
        )
        # Extraer contenido de forma segura tanto si resp es dict-like como objeto
        content = ""
        try:
            # intentar acceso estilo dict
            content = (resp.get("choices", [])[0].get("message", {}).get("content", "") if isinstance(resp, dict)
                       else getattr(resp.choices[0].message, "content", "") or resp.choices[0].message.get("content", ""))
        except Exception:
            # fallback adicional
            try:
                content = resp.choices[0].message["content"]
            except Exception:
                content = ""
        content = (content or "").strip()
        if not content:
            return "Lo siento, no obtuve una respuesta adecuada de OpenAI."
        return content
    except Exception as e:
        # Mensaje por defecto
        err_msg = "Lo siento, no puedo acceder a OpenAI en este momento."
        # Si la librería openai está disponible, intentar clasificar el error
        if openai_error is not None:
            if isinstance(e, openai_error.RateLimitError):
                err_msg = "OpenAI: límite de peticiones alcanzado, inténtalo más tarde."
            elif isinstance(e, openai_error.AuthenticationError):
                err_msg = "OpenAI: error de autenticación. Revisa tu API key."
            elif isinstance(e, openai_error.InvalidRequestError):
                err_msg = f"OpenAI: petición inválida ({type(e).__name__})."
        print("Error OpenAI:", type(e).__name__, str(e))
        return err_msg

def harvis():
    init_db()
    speak("Hola señor, soy Harvis. ¿En qué te puedo ayudar hoy?")
    try:
        while True:
            query = listen()
            if query is None:
                continue
            if "salir" in query.lower():
                speak("Hasta luego, señor.")
                break

            # Revisar memoria local
            memory_response = recall_memory(query)
            if memory_response:
                speak(memory_response)
                continue

            # Buscar en web
            web_info = search_web(query) or ""
            # Preparar prompt
            prompt = f"Combina esta información de internet con tu conocimiento general y dame una respuesta completa:\n{web_info}\n\nPregunta: {query}"
            ai_response = ask_openai(prompt)

            # Guardar en memoria sólo si la respuesta es válida y no es un mensaje de error informativo
            if ai_response and not ai_response.startswith(("No se ha configurado la clave de OpenAI", "Lo siento, no puedo acceder a OpenAI", "OpenAI:")):
                save_memory(query, ai_response)

            # Responder
            speak(ai_response)
    except KeyboardInterrupt:
        speak("Interrumpido por teclado. Hasta luego.")
        return

if __name__ == "__main__":
    harvis()
