import sqlite3

def init_db():
    conn = sqlite3.connect('memory.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS memory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            query TEXT,
            response TEXT
        )
    ''')
    conn.commit()
    conn.close()

def save_memory(query, response):
    conn = sqlite3.connect('memory.db')
    c = conn.cursor()
    c.execute('INSERT INTO memory (query, response) VALUES (?, ?)', (query, response))
    conn.commit()
    conn.close()

def recall_memory(query):
    conn = sqlite3.connect('memory.db')
    c = conn.cursor()
    c.execute('SELECT response FROM memory WHERE query LIKE ?', ('%'+query+'%',))
    results = c.fetchall()
    conn.close()
    return results[0][0] if results else None
