import os

# Intentar cargar .env si python-dotenv está disponible (opcional)
try:
    from dotenv import load_dotenv  # type: ignore
    load_dotenv()
except Exception:
    pass

def _int_env(name: str, default: int) -> int:
    v = os.getenv(name)
    if v is None or v == "":
        return default
    try:
        return int(v)
    except ValueError:
        return default

def _float_env_clamped(name: str, default: float, min_v: float = 0.0, max_v: float = 1.0) -> float:
    v = os.getenv(name)
    if v is None or v == "":
        return default
    try:
        f = float(v)
    except ValueError:
        return default
    # Clamp to range
    if f < min_v:
        return min_v
    if f > max_v:
        return max_v
    return f

# Clave de OpenAI (usa la variable de entorno OPENAI_API_KEY)
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()

# Configuración de la voz (con validación y valores por defecto)
VOICE_RATE = _int_env("VOICE_RATE", 150)
VOICE_VOLUME = _float_env_clamped("VOICE_VOLUME", 1.0)
